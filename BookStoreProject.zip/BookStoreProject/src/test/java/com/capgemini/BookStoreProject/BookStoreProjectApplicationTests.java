package com.capgemini.BookStoreProject;

//import org.junit.Test;
//import org.junit.runner.RunWith;
//

//@RunWith(SpringRunner.class)
//@SpringBootTest
//public class BookStoreProjectApplicationTests {
//
//	@Test
//	public void contextLoads() {
//	}
//
//}
