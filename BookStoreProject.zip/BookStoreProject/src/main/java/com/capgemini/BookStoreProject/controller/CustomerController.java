package com.capgemini.BookStoreProject.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.BookStoreProject.beans.Book;
import com.capgemini.BookStoreProject.beans.Cart;
import com.capgemini.BookStoreProject.beans.Orders;
import com.capgemini.BookStoreProject.beans.RegisterCustomer;
import com.capgemini.BookStoreProject.beans.Review;
import com.capgemini.BookStoreProject.exceptions.BookCannotBeAddedMoreAsItIsOutOfStockException;
import com.capgemini.BookStoreProject.exceptions.BookDoesNotExistException;
import com.capgemini.BookStoreProject.exceptions.CategoryDoesNotExistsException;
import com.capgemini.BookStoreProject.exceptions.CustomerDoesNotExistException;
import com.capgemini.BookStoreProject.exceptions.NoBookInTheCartException;
import com.capgemini.BookStoreProject.exceptions.NoBooksFoundException;
import com.capgemini.BookStoreProject.service.CustomerServiceImpl;

@RestController
public class CustomerController {

	@Autowired
	CustomerServiceImpl customerService;
	
	
	@RequestMapping(value="/")
	public String home()
	{
		return "home";
	}
//	@RequestMapping(value="/showAllUsers",method=RequestMethod.GET)
//	public List<Users> showAllUsers()
//	{
//		return customerService.listAllUsers();
//	}
//	
//	@RequestMapping(value="/showAllCustomers",method=RequestMethod.GET) 
//	public List<RegisterCustomer> showAllCustomers()
//	{
//		return customerService.listAllCutomers();
//	}
//	
//	
//	@RequestMapping(value="/createUser",method=RequestMethod.PUT)
//	public Users createUser(@RequestBody Users user) throws UserAlreadyExistException
//	{
//		return customerService.createUser(user);
//	}
//	
//	@RequestMapping(value="/createCustomer",method=RequestMethod.PUT)
//	public RegisterCustomer createCustomer(@RequestBody RegisterCustomer customer) throws CustomerAlreadyExistException
//	{
//		return customerService.registerCustomer(customer);
//	}
//	
//	@RequestMapping(value="/deleteUser/{id}",method=RequestMethod.DELETE)
//	public String deleteUser(@PathVariable int id) throws UserDoesNotExistException
//	{
//		return customerService.deleteUser(id);
//	}
//	
//	@RequestMapping(value="/editUser/{id}",method=RequestMethod.PUT)
//	public Users createUser(@PathVariable int id,@RequestBody Users user) throws UserDoesNotExistException
//	{
//		return customerService.editUser(id, user);
//	}
	
	@RequestMapping(value="/clearCart",method=RequestMethod.GET)
	public String clearCart()
	{
		return customerService.clearCart();
	}
	
	@RequestMapping(value="/addABookToCart",method=RequestMethod.PUT)
	public Map<Integer,Cart> addABookToCart(@RequestBody Book book)
	{
		return customerService.addABookToCart(book);
	}
	
	@RequestMapping(value="/removeABookFromCart/{id}",method=RequestMethod.DELETE)
	public Map<Integer,Cart> removeABookFromCart(@PathVariable int id) throws BookDoesNotExistException, NoBookInTheCartException
	{
		if(customerService.showCart().size()==1)
			{
			customerService.removeABookFromCart(id);

			}
		else
			return customerService.removeABookFromCart(id);
		return null;
	}

	@RequestMapping(value="/addQuantityOfBook/{cartId}",method=RequestMethod.GET)
	public Map<Integer,Cart> addQuantityOfBook(@PathVariable int cartId) throws BookCannotBeAddedMoreAsItIsOutOfStockException
	{
		return customerService.addQuantityOfBook(cartId);
	}
	
	@RequestMapping(value="/decreaseQuantityOfBook/{id}",method=RequestMethod.GET)
	public Map<Integer,Cart> decreaseQuantityOfBook(@PathVariable int id)
	{
		return customerService.decreaseQuantityOfBook(id);
	}
	
	@RequestMapping(value="/showCart",method=RequestMethod.GET)
	public Map<Integer,Cart> showCart() throws NoBookInTheCartException
	{
		return customerService.showCart();
	}
	
	@RequestMapping(value="/calculateCartTotal",method=RequestMethod.GET)
	public double calculateCartTotal() throws NoBookInTheCartException
	{
		return customerService.cartTotal();
	}
	
	
	
	
	
	
	
	
	
	
	/*  ____________________________________________________________________________________________ */
	
//	@RequestMapping(value = "/getOrdersForAdmin", method = RequestMethod.GET)
//	public List<Orders> getOrdersAdmin() {
//			return customerService.getOrdersForAdmin();
//	}
//	
//	@RequestMapping(value = "/orderDetail/{orderId}", method = RequestMethod.GET)
//	public Orders getOrderDetails(@PathVariable int orderId) {
//			return customerService.getOrderDeatilsByOrderId(orderId);
//	}
//	
//	
	@RequestMapping(value = "/confirmOrder", method = RequestMethod.PUT)
	public List<Orders> confirmOrder(@RequestBody Orders order) throws CustomerDoesNotExistException {
			return customerService.confirmOrder(order);
	}
//	
//	@RequestMapping(value = "/updateOrderByAdmin", method = RequestMethod.PUT)
//	public String updateOrderByAdmin(@RequestBody Orders order) throws OrderDoesNotExistException {
//			customerService.updateOrderByAdmin(order);
//			return "order updated successfully";
//	}
	
	@RequestMapping(value = "/loginCustomer/{phoneNumber}/{password}", method = RequestMethod.POST)
	public String updateOrderByAdmin(@PathVariable String phoneNumber, @PathVariable String password) throws CustomerDoesNotExistException {
			if(customerService.login(phoneNumber, password))
				return "login Successfully";
			else
				return "logon denied";

	}
	
	@RequestMapping(value = "/findOrderOfPerticularCustomer/{customerId}", method = RequestMethod.GET)
	public List<Orders> findOrderOfPerticularCustomer(@PathVariable int customerId) throws CustomerDoesNotExistException {
			return customerService.findAllOrdersOfPerticularCustomer(customerId);
	}
	
	/* _________________________________________________________________________________________________________*/
	
	
//	@RequestMapping(value="/createCategory",method=RequestMethod.PUT)
//	public Category createCategory(@RequestBody Category category) throws CategoryIdAlreadyExistsException
//	{
//		
//		return customerService.createCategory(category);
//	}
//	
//	@RequestMapping(value="/showcategory",method=RequestMethod.GET)
//	public List<Category> showCategory()
//	{
//		return customerService.findAllCategory();
//	}
//	
//	@RequestMapping(value="/deleteCategory/{categoryId}",method=RequestMethod.DELETE)
//	public Category deleteCategory(@PathVariable int categoryId) throws CategoryDoesNotExistsException
//	{
//		return customerService.deletecategory(categoryId);
//	}
//	
//
//	@RequestMapping(value="/editCategory",method=RequestMethod.PUT)
//	public Category editCategory(@RequestBody Category category) throws CategoryDoesNotExistsException
//	{
//		return customerService.editCategory(category);
//	}	
//	
	/*___________________________________________________________________________________________________________*/
	
	
	
	@RequestMapping(value="/categoryBooks/{category}",method=RequestMethod.GET)
	public List<Book> categoryBooks(@PathVariable String category) throws CategoryDoesNotExistsException
	{
		return customerService.categoryBooks(category);
	}
	
//	@RequestMapping(value="/showAllBooks",method=RequestMethod.GET)
//	public List<Book> showAllBooks() throws NoBooksFoundException
//	{
//		return customerService.showAllBooks();
//	}
	
	@RequestMapping(value="/recentBooks",method=RequestMethod.GET)
	public List<Book> recentBooks() throws NoBooksFoundException
	{
		return customerService.recentBooks();
	}
	
	@RequestMapping(value="/bestSellingBooks",method=RequestMethod.GET)
	public List<Book> bestSellingBooks() throws NoBooksFoundException
	{
		return customerService.bestSellingBooks();
	}
	
	@RequestMapping(value="/mostFavoredBooks",method=RequestMethod.GET)
	public List<Book> mostFavoredBooks() throws NoBooksFoundException
	{
		return customerService.mostFavoredBooks();
	}
	
	/*_________________________________________________________________________________________________________*/
	
	
	
//	@RequestMapping(value="/createBooks",method=RequestMethod.PUT)
//	public Book createBook(@RequestBody Book book) throws BookAlreadyExistException { 
//		return customerService.createBook(book);
//		}
//	
//	
//
//	@RequestMapping(value="/findBookById/{id}",method=RequestMethod.GET) 
//	public Book findBook(@PathVariable int id) throws BookIdDoesNotExistException { 
//		return customerService.findBook(id);
//		}
//	
//	
//	@RequestMapping(value="/updateBook",method=RequestMethod.PUT)  
//	public Book updateBook(@RequestBody Book book) throws BookDoesNotExistException {
//		return customerService.update( book);
//		}
//	
//	@RequestMapping(value="/deleteBook/{id}",method=RequestMethod.DELETE)
//	public List<Book> delete(@PathVariable int id) throws   BookIdDoesNotExistException {
//		return customerService.delete(id);
//		}	
	
	@RequestMapping(value="/booksReview/{reviewId}",method=RequestMethod.GET) 
	public List<Review> reviewOfPerticularBook(@PathVariable int reviewId)
	{
		return customerService.bookReview(reviewId);
		
	}
	
	
//	@RequestMapping(value="/bookInfo/{bookId}",method=RequestMethod.GET)
//	public Book bookInfo(@PathVariable int bookId) throws BookIdDoesNotExistException
//	{
//		return customerService.findBook(bookId);
//		
//	}
	
	/*_________________________________________________________________________________________________*/
	
	
	
	
	
//	@RequestMapping(value="/editCustomer",method=RequestMethod.PUT)
//	public List<RegisterCustomer> updateCustomer(@RequestBody RegisterCustomer customer) throws CustomerDoesNotExistException
//	{
//		return customerService.editCustomer(customer);
//
//    }
//	
//	
//	@RequestMapping(value="/deleteCustomer/{customerId}",method=RequestMethod.GET)
//	public List<RegisterCustomer> deleteCustomer(@PathVariable int customerId) throws CustomerDoesNotExistException
//	{
//		return customerService.deleteCustomer(customerId);
//	
//    }
//	
	@RequestMapping(value="/viewProfile/{customerId}",method=RequestMethod.GET)
	public RegisterCustomer viewProile(@PathVariable int customerId) throws CustomerDoesNotExistException
	{
		return customerService.viewProfile(customerId);

    }
	
	@RequestMapping(value="/editProfile",method=RequestMethod.PUT)
	public RegisterCustomer editProfile(@RequestBody RegisterCustomer customer) throws CustomerDoesNotExistException
	{
	return customerService.editProfile(customer);

    }
	
	/*___________________________________________________________________________________________________________*/
	
//	@RequestMapping(value = "/findAllReviews/{bookId}", method = RequestMethod.GET)
//	public List<Review> findAllReviews(@PathVariable int bookId) {
//			return customerService.findAllReviews(bookId);
//	} 
	
	@RequestMapping(value = "/saveReview/{bookId}", method = RequestMethod.PUT)
	public List<Review> saveReviews(@RequestBody Review reviews,@PathVariable int bookId) throws BookDoesNotExistException {
			return customerService.saveReviews(reviews,bookId);
	} 
	
//	@RequestMapping(value = "/updateReview/{reviewId}", method = RequestMethod.PUT)
//	public List<Review> updateReviews(@RequestBody Review reviews,@PathVariable int reviewId) throws ReviewDoesNotExistException {
//			return customerService.updateReview(reviews, reviewId);
//	} 
//	
//	@RequestMapping(value = "/deleteReview/{reviewId}", method = RequestMethod.DELETE)
//	public List<Review> deleteReviews(@PathVariable int reviewId) {
//			return customerService.deleteReview(reviewId);
//	} 
	
}