package com.capgemini.BookStoreProject.exceptions;

public class CustomerAlreadyExistException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public CustomerAlreadyExistException(String msg)
	{
		super(msg);
	}

}
