package com.capgemini.BookStoreProject.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.BookStoreProject.beans.Category;



public interface ICategoryDAO extends JpaRepository<Category, Integer> {

}