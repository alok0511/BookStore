package com.capgemini.BookStoreProject.exceptions;

public class OrderDoesNotExistException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public OrderDoesNotExistException(String msg) {
		super(msg);
		// TODO Auto-generated constructor stub
	}
	
	

}
