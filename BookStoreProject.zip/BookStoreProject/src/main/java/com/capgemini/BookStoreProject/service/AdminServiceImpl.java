package com.capgemini.BookStoreProject.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.BookStoreProject.beans.Book;
import com.capgemini.BookStoreProject.beans.Category;
import com.capgemini.BookStoreProject.beans.Orders;
import com.capgemini.BookStoreProject.beans.RegisterCustomer;
import com.capgemini.BookStoreProject.beans.Review;
import com.capgemini.BookStoreProject.beans.Users;
import com.capgemini.BookStoreProject.dao.IBookDAO;
import com.capgemini.BookStoreProject.dao.ICustomerDAO;
import com.capgemini.BookStoreProject.dao.ICategoryDAO;
import com.capgemini.BookStoreProject.dao.IOrdersDAO;
import com.capgemini.BookStoreProject.dao.IReviewDao;
import com.capgemini.BookStoreProject.dao.IUserDAO;
import com.capgemini.BookStoreProject.exceptions.BookAlreadyExistException;
import com.capgemini.BookStoreProject.exceptions.BookDoesNotExistException;
import com.capgemini.BookStoreProject.exceptions.BookIdDoesNotExistException;
import com.capgemini.BookStoreProject.exceptions.CategoryDoesNotExistsException;
import com.capgemini.BookStoreProject.exceptions.CategoryIdAlreadyExistsException;
import com.capgemini.BookStoreProject.exceptions.CustomerAlreadyExistException;
import com.capgemini.BookStoreProject.exceptions.CustomerDoesNotExistException;
import com.capgemini.BookStoreProject.exceptions.NoBooksFoundException;
import com.capgemini.BookStoreProject.exceptions.OrderDoesNotExistException;
import com.capgemini.BookStoreProject.exceptions.ReviewDoesNotExistException;
import com.capgemini.BookStoreProject.exceptions.UserAlreadyExistException;
import com.capgemini.BookStoreProject.exceptions.UserDoesNotExistException;

@Service
public class AdminServiceImpl implements IAdminService{
	

	@Autowired
	IUserDAO userDAO;
	
	@Autowired
	ICustomerDAO customerDAO;
	
	@Autowired
	IBookDAO bookDAO;
	
	@Autowired
	IOrdersDAO ordersDAO;
	
	@Autowired
	ICategoryDAO categoryDAO;
	
	@Autowired
	IReviewDao reviewDAO;
	
	
	@Override
	public Users createUser(Users user) throws UserAlreadyExistException {
	String email=user.getEmail();
	List<Users> userList=listAllUsers();
	for(Users list: userList)
		{
			if(email.equals(list.getEmail())) {
				throw new UserAlreadyExistException("This user already exist");
		}
	}
	userDAO.save(user);
	return user;
	}		

	@Override
	public RegisterCustomer registerCustomer(RegisterCustomer customer) throws CustomerAlreadyExistException {
		String phonenumber=customer.getPhonenumber();
		List<RegisterCustomer> customerList=listAllCutomers();
		for(RegisterCustomer list:customerList)
		{
			if(phonenumber.equals(list.getPhonenumber()))
				throw new CustomerAlreadyExistException("This customer already exist");
		}
			customerDAO.save(customer);
			return customer;
	}

	
	@Override
	public String deleteUser(int userId) throws UserDoesNotExistException {
		if(userDAO.existsById(userId))
		{
			userDAO.deleteById(userId);
			return "User Deleted Successfully";
		}
		else
			throw new UserDoesNotExistException("This User does not exist");
	}

	@Override
	public Users editUser(int userId,Users updatedUser) throws UserDoesNotExistException {
		if(userDAO.existsById(userId) && updatedUser.getId()==userId)
		{
				userDAO.deleteById(userId);
				userDAO.saveAndFlush(updatedUser);
				return updatedUser;
		}
		else
			throw new UserDoesNotExistException("This user does not exist");
	}
	
	@Override
	public List<Users> listAllUsers() {
		
		return userDAO.findAll();
	}
	
	@Override
	public List<RegisterCustomer> listAllCutomers() {
		
		return customerDAO.findAll();
	}

	@Override
	public List<Orders> getOrdersForAdmin() {
		
		return ordersDAO.findAll();
	}
	
	@Override
	public Orders getOrderDeatilsByOrderId(int orderId) {
		
		return ordersDAO.findById(orderId).get();
	}
	
	@Override
	public void updateOrderByAdmin(Orders order) throws OrderDoesNotExistException
	{
		if(!ordersDAO.existsById(order.getId()))
			throw new OrderDoesNotExistException("Order does not exist");
		ordersDAO.saveAndFlush(order);
	}

	@Override
	public Category createCategory(Category category) throws CategoryIdAlreadyExistsException {
		List<Category> categories = categoryDAO.findAll();
		for (Category checkcategory:categories)
		{
			if(checkcategory.getCategoryName().equals(category.getCategoryName()))
			{
				throw new CategoryIdAlreadyExistsException("This Category Already Exists");
			}
		}
		return categoryDAO.saveAndFlush(category);
	}
	
	@Override
	public List<Category> findAllCategory() {
		return categoryDAO.findAll();
	}

	@Override
	public Category deletecategory(int categoryId) throws CategoryDoesNotExistsException {
		List<Category> categories = categoryDAO.findAll();
		for(Category checkcategory:categories)
		{
			if(checkcategory.getCategoryId() == categoryId)
			{
				categoryDAO.deleteById(categoryId);
				return null;
			}
		}
		throw new CategoryDoesNotExistsException("Category Id does not exists");
		
	}

	@Override
	public Category editCategory(Category category) throws CategoryDoesNotExistsException {
		List<Category> categories = categoryDAO.findAll();
		for(Category checkcategory:categories)
		{
			if(checkcategory.getCategoryId() == category.getCategoryId())
			{
				return categoryDAO.saveAndFlush(category);
			}
		}
		throw new CategoryDoesNotExistsException("Category Id does not exists");
		
	}

	@Override
	public List<Book> showAllBooks() throws NoBooksFoundException {
		List<Book> allBooks =  bookDAO.findAll();
		if(allBooks.isEmpty())
		{
			throw new NoBooksFoundException("No books Found");
		}
		return allBooks;
	}
	
	@Override
	public Book createBook(Book book) throws BookAlreadyExistException {

		List<Book> allBook= bookDAO.findAll();
		for(Book book1:allBook)
		{
			if(book1.getTitle().equals(book.getTitle()))
			{
				throw new BookAlreadyExistException("Book ID Already Exist");
			}
		}
		
		return bookDAO.saveAndFlush(book);
	}

	@Override
	public Book findBook(int id) throws BookIdDoesNotExistException {

		if (!bookDAO.existsById(id))
			throw new BookIdDoesNotExistException("Book Id does not Exist");

		return bookDAO.findById(id).get();
	}

	@Override
	public Book update(Book book) throws BookDoesNotExistException {
		
		if(!bookDAO.existsById(book.getBookId()))
			throw new BookDoesNotExistException("Book Does Not Exist");
		else {
			return bookDAO.saveAndFlush(book);
		}
	}
	
	@Override
	public List<Book> delete(int id) throws  BookIdDoesNotExistException {
		
		if(bookDAO.existsById(id)) {
			bookDAO.deleteById(id);
			return bookDAO.findAll();
		}
		else
			throw new BookIdDoesNotExistException("Book Id does not exist");
	}
	
	@Override
	public List<RegisterCustomer> editCustomer(RegisterCustomer customer) throws CustomerDoesNotExistException {
		if(customerDAO.existsById(customer.getCustomerId())) {
			customerDAO.saveAndFlush(customer);
			return customerDAO.findAll();
		}
		throw new CustomerDoesNotExistException("customer does not exist");
	}

	@Override
	public List<RegisterCustomer> deleteCustomer(int customerId) throws CustomerDoesNotExistException{
		
		if(customerDAO.existsById(customerId))
		{
			customerDAO.deleteById(customerId);
			return customerDAO.findAll();
		}
		
		throw new CustomerDoesNotExistException("customer does not exist");
	}
	
	public List<Review> findAllReviews(int bookId) {
		return reviewDAO.findAll();
			
		}
	
		@Override
		public List<Review> updateReview(Review review,int reviewId) throws ReviewDoesNotExistException {
			if(reviewDAO.existsById(reviewId))
			{
				reviewDAO.deleteById(reviewId);
				reviewDAO.save(review);
				return reviewDAO.findAll();
			}
			else
				throw new ReviewDoesNotExistException("This review does not exist");
			
		}
		
		
		@Override
		public List<Review> deleteReview(int reviewId) {
	      reviewDAO.deleteById(reviewId);
		return reviewDAO.findAll();
		}
	
	

}
