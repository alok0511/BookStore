package com.capgemini.BookStoreProject.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.capgemini.BookStoreProject.beans.Book;
import com.capgemini.BookStoreProject.beans.Category;
import com.capgemini.BookStoreProject.beans.Orders;
import com.capgemini.BookStoreProject.beans.RegisterCustomer;
import com.capgemini.BookStoreProject.beans.Review;
import com.capgemini.BookStoreProject.beans.Users;
import com.capgemini.BookStoreProject.exceptions.BookAlreadyExistException;
import com.capgemini.BookStoreProject.exceptions.BookDoesNotExistException;
import com.capgemini.BookStoreProject.exceptions.BookIdDoesNotExistException;
import com.capgemini.BookStoreProject.exceptions.CategoryDoesNotExistsException;
import com.capgemini.BookStoreProject.exceptions.CategoryIdAlreadyExistsException;
import com.capgemini.BookStoreProject.exceptions.CustomerAlreadyExistException;
import com.capgemini.BookStoreProject.exceptions.CustomerDoesNotExistException;
import com.capgemini.BookStoreProject.exceptions.NoBooksFoundException;
import com.capgemini.BookStoreProject.exceptions.OrderDoesNotExistException;
import com.capgemini.BookStoreProject.exceptions.ReviewDoesNotExistException;
import com.capgemini.BookStoreProject.exceptions.UserAlreadyExistException;
import com.capgemini.BookStoreProject.exceptions.UserDoesNotExistException;

@Service
public interface IAdminService {
	
	public Users createUser(Users user) throws UserAlreadyExistException;
	
	public String deleteUser(int userId) throws UserDoesNotExistException;
	
	public Users editUser(int userId,Users updatedUser) throws UserDoesNotExistException;
	
	public List<Users> listAllUsers();
	
	public RegisterCustomer registerCustomer(RegisterCustomer customer) throws CustomerAlreadyExistException;
	
	public List<RegisterCustomer> listAllCutomers();
	
	List<RegisterCustomer> editCustomer(RegisterCustomer customer) throws CustomerDoesNotExistException;

	List<RegisterCustomer> deleteCustomer(int customerId) throws CustomerDoesNotExistException;

	
	public List<Orders> getOrdersForAdmin();
	
	public Orders getOrderDeatilsByOrderId(int orderId);
	
	void updateOrderByAdmin(Orders order) throws OrderDoesNotExistException;
	
	public Category createCategory(Category category) throws CategoryIdAlreadyExistsException;
	
	public List<Category> findAllCategory();

	Category deletecategory(int categoryId) throws CategoryDoesNotExistsException;

	Category editCategory(Category category) throws CategoryDoesNotExistsException;

	List<Book> showAllBooks() throws NoBooksFoundException;
	
	Book createBook(Book book) throws BookAlreadyExistException;

	Book findBook(int id) throws BookIdDoesNotExistException;

	Book update(Book book) throws BookDoesNotExistException;

	List<Book> delete(int id) throws BookIdDoesNotExistException;
	
	List<Review> findAllReviews(int bookId);

	List<Review> updateReview(Review review, int reviewId) throws ReviewDoesNotExistException;

	List<Review> deleteReview(int reviewId);

	

}
