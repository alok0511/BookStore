package com.capgemini.BookStoreProject.controller;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.capgemini.BookStoreProject.exceptions.BookAlreadyExistException;
import com.capgemini.BookStoreProject.exceptions.BookCannotBeAddedMoreAsItIsOutOfStockException;
import com.capgemini.BookStoreProject.exceptions.BookDoesNotExistException;
import com.capgemini.BookStoreProject.exceptions.BookIdDoesNotExistException;
import com.capgemini.BookStoreProject.exceptions.CategoryDoesNotExistsException;
import com.capgemini.BookStoreProject.exceptions.CategoryIdAlreadyExistsException;
import com.capgemini.BookStoreProject.exceptions.CustomerAlreadyExistException;
import com.capgemini.BookStoreProject.exceptions.CustomerDoesNotExistException;
import com.capgemini.BookStoreProject.exceptions.NoBookInTheCartException;
import com.capgemini.BookStoreProject.exceptions.NoBooksFoundException;
import com.capgemini.BookStoreProject.exceptions.OrderDoesNotExistException;
import com.capgemini.BookStoreProject.exceptions.ReviewDoesNotExistException;
import com.capgemini.BookStoreProject.exceptions.UserAlreadyExistException;
import com.capgemini.BookStoreProject.exceptions.UserDoesNotExistException;

@ControllerAdvice
public class BookStoreExceptionHandler  extends ResponseEntityExceptionHandler {

	@ExceptionHandler(value = BookCannotBeAddedMoreAsItIsOutOfStockException.class)
	public ResponseEntity<Object> bookCannotBeAddedMoreAsItIsOutOfStockException(BookCannotBeAddedMoreAsItIsOutOfStockException e)
	{
		return new ResponseEntity<>(e.getMessage(),HttpStatus.NOT_FOUND);
	}
	

	@ExceptionHandler(value = BookDoesNotExistException.class)
	public ResponseEntity<Object> bookDoesNotExistException(BookDoesNotExistException e)
	{
		return new ResponseEntity<>(e.getMessage(),HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(value = CustomerAlreadyExistException.class)
	public ResponseEntity<Object> customerAlreadyExistException(CustomerAlreadyExistException e)
	{
		return new ResponseEntity<>(e.getMessage(),HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(value = NoBookInTheCartException.class)
	public ResponseEntity<Object> noBookInTheCartException(NoBookInTheCartException e)
	{
		return new ResponseEntity<>(e.getMessage(),HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(value = UserAlreadyExistException.class)
	public ResponseEntity<Object> userAlreadyExistException(UserAlreadyExistException e)
	{
		return new ResponseEntity<>(e.getMessage(),HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(value = UserDoesNotExistException.class)
	public ResponseEntity<Object> userDoesNotExistException(UserDoesNotExistException e)
	{
		return new ResponseEntity<>(e.getMessage(),HttpStatus.NOT_FOUND);
	}
	
	
	@ExceptionHandler(value = CustomerDoesNotExistException.class)
	public ResponseEntity<Object> customerDoesNotExistException(CustomerDoesNotExistException e)
	{
		return new ResponseEntity<>(e.getMessage(),HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(value = OrderDoesNotExistException.class)
	public ResponseEntity<Object> orderDoesNotExistException(OrderDoesNotExistException e)
	{
		return new ResponseEntity<>(e.getMessage(),HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(value =CategoryDoesNotExistsException.class)
	public ResponseEntity<Object> categoryDoesNotExistsException(CategoryDoesNotExistsException e)
	{
		return new ResponseEntity<>(e.getMessage(),HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(value = CategoryIdAlreadyExistsException.class)
	public ResponseEntity<Object> categoryAlredyExistsException(CategoryIdAlreadyExistsException e)
	{
		return new ResponseEntity<>(e.getMessage(),HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(value = NoBooksFoundException.class)
	public ResponseEntity<Object> noBoksFoundException(NoBooksFoundException e)
	{
		return new ResponseEntity<>(e.getMessage(),HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(value = BookIdDoesNotExistException.class)
	public ResponseEntity<Object> bookIdDoesNotExistException(BookIdDoesNotExistException e)
	{
		return new ResponseEntity<>(e.getMessage(),HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(value = BookAlreadyExistException.class)
	public ResponseEntity<Object> bookAlreadyExistException(BookAlreadyExistException e)
	{
		return new ResponseEntity<>(e.getMessage(),HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(value = ReviewDoesNotExistException.class)
	public ResponseEntity<Object> reviewDoesNotExistException(ReviewDoesNotExistException e)
	{
		return new ResponseEntity<>(e.getMessage(),HttpStatus.NOT_FOUND);
	}
	
	
	
	@Override
	public ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException e, HttpHeaders headers,
			HttpStatus status, WebRequest request) {

		return new ResponseEntity<>(e.getBindingResult().getAllErrors().get(0).getDefaultMessage(),
				HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	
}
