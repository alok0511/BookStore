package com.capgemini.BookStoreProject.exceptions;

public class BookAlreadyExistException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public BookAlreadyExistException(String msg) {
		super(msg);
		// TODO Auto-generated constructor stub
	}
	
	

}
